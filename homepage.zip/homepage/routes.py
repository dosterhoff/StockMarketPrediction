from flask import render_template, url_for, flash, redirect
from homepage import app, db, bcrypt
from homepage.forms import RegistrationForm, LoginForm
from homepage.models import User, Post
from flask_login import login_user, current_user, logout_user





@app.route("/stock")
def stock():
    return render_template('stock.html', title='StockNews')

@app.route("/buyandsell")
def buyandsell():
    return render_template('buyandsell.html', title='Buyandsell')

@app.route("/Southwestern")
def agentaction1():
    return render_template('agentactionsouth.html', title='Agent')

@app.route("/Apple")
def agentaction2():
    return render_template('agentactionAAPL.html', title='AgentA')

@app.route("/BoeingAerospace")
def agentaction3():
    return render_template('agentactionBA.html', title='AgentB')

@app.route("/Starbucks")
def agentaction4():
    return render_template('agentactionstar.html', title='AgentS')

@app.route("/Ford")
def agentaction5():
    return render_template('agentactionFord.html', title='AgentFord')

@app.route("/GeneralMotors")
def agentaction6():
    return render_template('agentactionGM.html', title='AgentGM')

@app.route("/GeneralElectronics")
def agentaction7():
    return render_template('agentactionGE.html', title='AgentGE')




@app.route("/")
@app.route("/home")
def home():
    return render_template('home.html')


@app.route("/about")
def about():
    return render_template('about.html', title='About')


@app.route("/register", methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form = RegistrationForm()
    if form.validate_on_submit():
        hashed_password=bcrypt.generate_password_hash(form.password.data)
        user = User(username=form.username.data, email=form.email.data, password=hashed_password)
        db.session.add(user)
        db.session.commit()
        flash('Welcome To Stock Watch you can now log in', 'success')
        return redirect(url_for('login'))
    return render_template('register.html', title='Register', form=form)


@app.route("/login", methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            login_user(user, remember=form.remember.data)
            return redirect(url_for('home'))
        else:
            flash('Login Unsuccessful. Please check email and password', 'danger')
    return render_template('login.html', title='Login', form=form)

@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for('home'))
